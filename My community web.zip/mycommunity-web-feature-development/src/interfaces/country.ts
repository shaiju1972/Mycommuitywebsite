export interface ICountry {
    code: string;
    name: string;
}
