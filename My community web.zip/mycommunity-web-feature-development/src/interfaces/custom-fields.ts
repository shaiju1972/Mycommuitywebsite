export interface ICustomFields {
    [fieldName: string]: any;
}
