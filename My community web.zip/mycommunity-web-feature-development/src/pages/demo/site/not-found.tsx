import Page from '~/pages/404';

export default Page;
