import SitePageNotFound from '~/components/site/SitePageNotFound';

export default SitePageNotFound;
