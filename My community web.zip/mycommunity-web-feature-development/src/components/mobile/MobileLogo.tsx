// react
import React from 'react';

function MobileLogo() {
    return (
        <div className="mobile-logo">
            {/* mobile-logo */}
            <svg width="130" height="20">
                
                
            </svg>
            {/* mobile-logo / end */}
        </div>
    );
}

export default MobileLogo;
