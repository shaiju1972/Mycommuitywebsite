export interface IVehicle {
    id: number;
    year: number;
    make: string;
    model: string;
    engine: string;
}
