// application
import Page from './[slug]/index';

export { getServerSideProps } from './[slug]/index';

export default Page;
