const theme = {
    name: 'RedParts',
    url: '.',
    author: {
        name: '.',
        profile_url: '.',
    },
    contacts: {
        address: ['Retej Building, No.299, Doha, Qatar'],
        email: ['support@mycommunity.qa'],
        phone: ['+974 (800) 010-01-10'],
        hours: ['Sat-Thu 10:00pm - 7:00pm'],
    },
};

export default theme;
