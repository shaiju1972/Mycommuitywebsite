const dataSiteTeammates = [
    {
        name: 'Michael Russo',
        position: 'Chief Executive Officer',
        avatar: '/images/teammates/teammate1.jpg',
    },
    {
        name: 'Samantha Smith',
        position: 'Account Manager',
        avatar: '/images/teammates/teammate2.jpg',
    },
    {
        name: 'Anthony Harris',
        position: 'Finance Director',
        avatar: '/images/teammates/teammate3.jpg',
    },
    {
        name: 'Katherine Miller',
        position: 'Marketing Officer',
        avatar: '/images/teammates/teammate4.jpg',
    },
    {
        name: 'Boris Gilmore',
        position: 'Engineer',
        avatar: '/images/teammates/teammate5.jpg',
    },
];

export default dataSiteTeammates;
