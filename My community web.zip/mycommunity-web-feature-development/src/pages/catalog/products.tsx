// application
import Page from './[slug]/products';

export { getServerSideProps } from './[slug]/products';

export default Page;
