export interface IUser {
    // email: string;
    // phone: string;
    // firstName: string;
    // lastName: string;
    // avatar: string;
    ccd: string;
    email: string;
    firstLogin: boolean;
    mobile: string;
    name: string;
    profilePic:string;
    referenceNumber: string;
    token: string;
    userRole: number
    username: string
    _id: string;
}
