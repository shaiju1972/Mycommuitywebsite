import Page from '~/pages/demo/site/contact-us-v1';

export default Page;
