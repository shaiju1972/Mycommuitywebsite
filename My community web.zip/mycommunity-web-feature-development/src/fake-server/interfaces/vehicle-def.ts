export interface IVehicleDef {
    year: number | [number, number];
    make: string;
    model: string;
    engine: string;
}
