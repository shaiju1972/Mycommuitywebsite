export interface IReview {
    id: number;
    date: string;
    author: string;
    avatar: string;
    rating: number;
    content: string;
}
